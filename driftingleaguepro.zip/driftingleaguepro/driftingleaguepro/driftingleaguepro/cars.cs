﻿using System;
using System.Text;
namespace driftingleaguepro
{
    public class cars
    {
        public string Thumbnail { get; set; }
        public string Thumbnail_Large { get; set; }
        public string Content { get; set; }
        public string Title { get; set; }

    }
}
