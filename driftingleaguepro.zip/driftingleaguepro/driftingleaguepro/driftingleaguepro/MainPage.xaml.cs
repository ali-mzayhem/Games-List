﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;
using System.Reflection;
using Newtonsoft.Json;
using System.IO;
using Xamarin.Essentials;
using driftingleaguepro;

namespace driftingleaguepro
{
    public partial class MainPage : ContentPage
    {
        private ObservableCollection<cars> sc;
        public MainPage()
        {
            InitializeComponent();
            Soccer();

        }

        public async void Soccer()
        {
            try
            {
                var assembly = typeof(MainPage).GetTypeInfo().Assembly;
                Stream stream = assembly.GetManifestResourceStream("driftingleaguepro.cars.json");
                using (var reader = new System.IO.StreamReader(stream))
                {
                    var json = reader.ReadToEnd();

                    List<cars> mylist = JsonConvert.DeserializeObject<List<cars>>(json);
                    sc = new ObservableCollection<cars>(mylist);
                    GameList.ItemsSource = sc;
                }
            }
            catch (Exception e)
            {
                await DisplayAlert("Alert", "error", "ok");
            }

        }
        public async Task OpenBrowser(Uri uri)
        {
            try
            {
                await Browser.OpenAsync(uri, BrowserLaunchMode.SystemPreferred);
            }
            catch (Exception ex)
            {
                // An unexpected error occured. No browser may be installed on the device.
            }
        }

        void Button_Clicked(Object sender, EventArgs e)
        {

            string Content = ((Button)sender).BindingContext as string;
            Uri uri = new Uri(Content);
            _ = OpenBrowser(uri);
        }

    }
}
